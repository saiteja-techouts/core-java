package constructorsPackage;

public class DefaultConstructor {
	int id;
	String name;
	void display()
	{
		System.out.println("id is "+id+"name is "+name);
	}
	public static void main(String[] args) {
		//default constructor is used to provide the values like 0,null to the created object
		DefaultConstructor d1=new DefaultConstructor();
		DefaultConstructor d2=new DefaultConstructor();
		d1.display();
		d2.display();
	}

}
