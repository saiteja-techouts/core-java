package constructorsPackage;

public class CopyWOconstructors {
int id;
String name;
CopyWOconstructors(int i,String n)
{
id=i;
name=n;
}
CopyWOconstructors()
{
	
}
void disp()
{
System.out.println(id+" "+name);	
}
}
class Cwoutconstructor
{
public static void main(String[] args) {
	CopyWOconstructors cw=new CopyWOconstructors(111,"teja");
	CopyWOconstructors cw1=new CopyWOconstructors();
	cw1.id=cw.id;
	cw1.name=cw.name;
	cw.disp();
	cw1.disp();
}	
}
