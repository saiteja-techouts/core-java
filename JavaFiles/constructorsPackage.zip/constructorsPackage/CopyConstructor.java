package constructorsPackage;
//copy values with constructor.

//copy constructor is used to copy the values of one object to another object.
public class CopyConstructor {
int id;
String name;
public CopyConstructor(int i,String n) {
	id=i;
	name=n;
}
//in 11th line constructor is used to initialize another object
public CopyConstructor(CopyConstructor cc) {
id=cc.id;
name=cc.name;
}
void disp() 
{
 System.out.println(id+" "+name);	
}
}
class Cconstructor
{
public static void main(String[] args) {
	CopyConstructor c1=new CopyConstructor(1,"sai");
	CopyConstructor c2=new CopyConstructor(c1);
	c1.disp();
	c2.disp();
}	
}
