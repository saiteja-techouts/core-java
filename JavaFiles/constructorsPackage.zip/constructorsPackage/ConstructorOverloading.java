package constructorsPackage;

public class ConstructorOverloading {
	int id;
	String name;
	int age;
    public ConstructorOverloading(int i,String n,int a) {
	id=i;
	name=n;
	age=a;
	}
  /*  void display()
    {
    	System.out.println(id+" "+name+" "+age);
    }*/
   public ConstructorOverloading(int i,String n)
    {
    	id=i;
    	name=n;
    }
    void show()
    {
    	System.out.println(id+" "+name+" "+age);
    }
}
class Co
{
 public static void main(String[] args) {
	ConstructorOverloading co=new ConstructorOverloading(1, "sai",25);
	ConstructorOverloading co1=new ConstructorOverloading(2,"teja");
	//co.display();
	co.show();
	co1.show();
}	
}
