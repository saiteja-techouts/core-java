package constructorsPackage;

public class ParameterizedConstructor {
	int id;
	String name;
	public ParameterizedConstructor(int i,String n) {
	id=i;
	name=n;
	}
	void disp()
	{
		System.out.println(id+" "+name);
	}
public static void main(String[] args) {
	ParameterizedConstructor p1=new ParameterizedConstructor(1, "sai");
	ParameterizedConstructor p2=new ParameterizedConstructor(2,"teja");
	p1.disp();
	p2.disp();
}
}
