package staticPackage;

public class WithoutStatic {
int count=0;
public WithoutStatic() {
 count++;//incrementing the value of instance variable
	System.out.println(count);
}
}
class Ws
{
public static void main(String[] args) {
	//whenever we create an object the memory is allocated for instance variable, and each object having the copy of instance variable.
	WithoutStatic ws=new WithoutStatic();
	WithoutStatic ws1=new WithoutStatic();
	WithoutStatic ws2=new WithoutStatic();
	//if it is incremented it won't reflect another objects, and the value cannot change.
}	
}
