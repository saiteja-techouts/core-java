package staticPackage;

public class StaticExample {
	int stuId;//instance variable
	String stuName;
	static String clgName="UEL";//static variable, it is used for memory management 
	
	public StaticExample(int id,String name) {
	stuId=id;
	stuName=name;
	}
	void disp()
	{
		System.out.println(stuId+" "+stuName+" "+clgName);
	}

}
class Student
{
public static void main(String[] args) {
	StaticExample se=new StaticExample(111, "Thomas");
	StaticExample se1=new StaticExample(112,"Andy");
	se.disp();
	se1.disp();
}	
}
