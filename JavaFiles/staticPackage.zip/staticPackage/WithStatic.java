package staticPackage;

public class WithStatic {
	static int count=0;
	WithStatic(){
		count++;
		System.out.println(count);
	}
	public static void main(String[] args) {
		WithStatic ws=new WithStatic();
		WithStatic ws1=new WithStatic();
		//static memory can be allocated only once, the static variable can changes when the object is created
	}
}
