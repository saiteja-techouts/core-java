package staticPackage;

public class StaticMethod {
int id;
String name;
static String college="MIT";
//creating static method
static void change()
{
//static method can directly change the value of static variable
	college="VIT";
}
StaticMethod(int i,String n)
{
id=i;
name=n;
	}
void disp()
{
System.out.println(id+" "+name+" "+college);	
}

public static void main(String[] args) {
	//static methods can call directly, no need of instantiating the class
	StaticMethod.change();
	StaticMethod sm1=new StaticMethod(111,"Tom");
	StaticMethod sm2=new StaticMethod(112,"JD");
	sm1.disp();
	sm2.disp();
}
}
