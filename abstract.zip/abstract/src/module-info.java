module abstractModule {
}