package operatorsPackage;

public class AssignmentOperator {
	public static void main(String[] args) {
		int a=6;
		int temp=a;
		System.out.println("temp using: "+ a);
		/*=
		 * +=
		 * -=
		 * %=
		 * *=*/
		temp += a;//temp =temp+a
		System.out.println("temp using: "+temp);
		temp *= a;//temp =temp+b
		System.out.println("temp using: "+temp);
		
	    
	}
	 

}
