package operatorsPackage;

public class LogicalOperators {
	public static void main(String[] args) {
		int a=1;
		float b=1.1f;
			if((a==b)||(a<=b))
			{
				System.out.println("Music");
			}
			else if((a>=b)&&(b<=a))
			{
				System.out.println("Dance");
			}
			if(a<=b)
			{
				if(b>=a ||a==b)
				{
					System.out.println("Play Suriya Album");
				}
				else
				{
					System.out.println("Play Private Album");
				}
			}
			else
			{
				System.out.println("Exit library");
			}
			
			String output=(a%b==0)?"even":"odd";
			System.out.println(output);
			
			//if we want to typecast boolean to int  
			boolean bool= true;
			int val=(bool)?1:0;
			System.out.println(val);
			
	}

}
