package thisPackage;

public class ThisExample3 {
	int id;
	String name;
	float fee;
	static String college="KU";
	static void change()
	{
	college="MVSR";	
	}
	ThisExample3(int id,String name,float fee)
	{
	this.id=id;
	this.name=name;
	this.fee=fee;
		}
	void disp()
	{
	System.out.println(id+" "+name+" "+fee+" "+college);	
	}

	public static void main(String[] args) {
		ThisExample3.change();
		ThisExample3 te2=new ThisExample3(1, "sai",120000.0f);
		ThisExample3 te3=new ThisExample3(2, "teja",30000.0f);
				te2.disp();
				te3.disp();
				
				// having same parameters and instance variables.by distinguishing loacal and instance variables by using this keyword 
	}

}
