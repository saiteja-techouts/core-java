package thisPackage;

public class ThisMethod {
//this key word is used to call the current class mthod.
	void disp()
	{
		System.out.println("hello");
	}
	void Show()
	{
		System.out.println("this is show method");
		this.disp();
	}
	
}
class Tm{
	public static void main(String[] args) {
		ThisMethod tm=new ThisMethod();
		tm.Show();
	}
}
