package thisPackage;

public class ThisExample {
//this keyword is the reference variable that refers to the current object.
	//program where this is not required.
	int id;
	String name;
	static String college="BITS";
	static void Change()
	{
		college="GITAMS";
	}
	public ThisExample(int i,String n) {
	id=i;
	name=n;
	}
	void show()
	{
		System.out.println(id+" "+name+" "+college);
	}
	public static void main(String[] args) {
		ThisExample.Change();
		ThisExample te=new ThisExample(1, "Dani");
		ThisExample te1=new ThisExample(2,"George");
		te.show();
		te1.show();
	}
}
