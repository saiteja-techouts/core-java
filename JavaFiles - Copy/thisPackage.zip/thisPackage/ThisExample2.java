package thisPackage;

public class ThisExample2 {
int id;
String name;
float fee;
static String college="KU";
static void change()
{
college="MVSR";	
}
ThisExample2(int id,String name,float fee)
{
id=id;
name=name;
fee=fee;
	}
void disp()
{
System.out.println(id+" "+name+" "+fee+" "+college);	
}

public static void main(String[] args) {
	ThisExample2.change();
	ThisExample2 te2=new ThisExample2(1, "sai",120000.0f);
	ThisExample2 te3=new ThisExample2(2, "teja",30000.0f);
			te2.disp();
			te3.disp();
			
			//above the parameters and instance varibles are same. we overcome this problem by distinguishing loacal and instance variables by using this keyword.
}
}
