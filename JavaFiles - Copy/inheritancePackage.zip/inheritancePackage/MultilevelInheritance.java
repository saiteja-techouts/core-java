package inheritancePackage;
//the class which is derived from another derived class is a multilevel inheritance.
public class MultilevelInheritance {
static void displ()
{
	System.out.println("This is superclass");
	}
}
class Programmer extends MultilevelInheritance{
	static void show()
	{
		System.out.println("this is derived class");
	}
	Programmer()
	{
		System.out.println("I am constructor in first dervied");
	}
}
class Programmer1 extends Programmer{
	static void add()
	{
		System.out.println("This is derived class");
	}
}

class Text1
{
public static void main(String[] args) {
	Programmer1 p1=new Programmer1();
     p1.add();	
}	
}
