package inheritancePackage;

public class SingleInheritance {
int a=10;
double d=122678;
float f=122.f;
static void disp()
{
System.out.println("this is super class");	
}
}

class Programmer3 extends SingleInheritance
{
 static void Show()
 {
	 System.out.println("this is child class");
 }
}

class text
{
public static void main(String[] args) {
	Programmer3 p1=new Programmer3();
	p1.disp();
	p1.Show();
}	
}
