package inheritancePackage;

public class HierarichalInheritance {
//two subclasses which can inherit from a single class is hierarichal inheritance
	void add()
	{
		System.out.println("this is add");
	}
}
class Sub extends HierarichalInheritance
{
 void sub()
 {
	 System.out.println("this is sub ");
 }
}
class Mul extends HierarichalInheritance
{
void mul()
{
	 System.out.println("this is mul");	
}
}
class Ht
{
public static void main(String[] args) {
//	Mul m1=new Mul();
//	m1.add();
//	m1.mul();
	//m1.sub() gets an compile time error
	HierarichalInheritance h1=new HierarichalInheritance();
	h1.add();
	

}	
}