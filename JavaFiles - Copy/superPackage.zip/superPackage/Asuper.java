package superPackage;

//invoking parent class instance variable.
public class Asuper {
int Dogage=5;
}
class Dog extends Asuper
{
int Dogage=10;
void dogBreed()
{
System.out.println("germanSheperd "+ Dogage);
System.out.println("gradian "+ super.Dogage);
}
}
class Animal
{
public static void main(String[] args) {
	Dog d1=new Dog();
	d1.dogBreed();
}	
}
