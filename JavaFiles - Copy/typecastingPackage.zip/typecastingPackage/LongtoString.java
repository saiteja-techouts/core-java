package typecastingPackage;

public class LongtoString {
public static void main(String[] args) {
	long l1=876543219;
	String s=String.valueOf(l1);
	System.out.println(s+"c");
}
}
