package typecastingPackage;

public class ChartoString {
public static void main(String[] args) {
	char ch='a';
	String s=String.valueOf(ch);
	System.out.println(s);
}
}
