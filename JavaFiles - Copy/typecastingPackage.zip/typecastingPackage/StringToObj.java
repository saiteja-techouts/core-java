package typecastingPackage;

public class StringToObj {
public static void main(String[] args) {
	//we can convert string into obj directly because obj is a Control Class/parent class
	String s=" ";
	Object ob=s;
	System.out.println(ob);
}
}
