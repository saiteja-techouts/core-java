package typecastingPackage;

public class CharToInt {
public static void main(String[] args) {
	char c='a';
	char c1='A';
	char c2='1';
	//if we assign char to int directly it gives ASCII value
	int a=c;
	int a1=c1;
	int a2=c2;
	System.out.println(a);
	System.out.println(a1);
	System.out.println(a2);
	
	//if character contains int value, if we want to get int value, use Character.getNumericValue(char)
	int a3=Character.getNumericValue(c2);
	System.out.println(a3);
}
}
