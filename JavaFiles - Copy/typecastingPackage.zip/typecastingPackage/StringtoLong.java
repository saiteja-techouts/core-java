package typecastingPackage;

public class StringtoLong {
public static void main(String[] args) {
	String s="987654321";
	/*String to long =>Long.parseLong()
      Long to string=>String.valueOf() or Long.toString()*/
	Long l=Long.parseLong(s);
	System.out.println(l);
}
}
