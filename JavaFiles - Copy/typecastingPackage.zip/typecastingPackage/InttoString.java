package typecastingPackage;

public class InttoString {
public static void main(String[] args) {
	int a=5;
	int b=6;
	int c=a+b;
	//if we want to convert int to string, use String.valueOf(); and Integer.toString()
	String s=String.valueOf(c);
	System.out.println(s+c);
	
	//Integer.toString()
	String s1=Integer.toString(c);
	System.out.println(s1+23);
}
}
