package typecastingPackage;

public class StringtoInt {
	public static void main(String[] args) {
		//if we want to convert string to int, use Integer.parseInt(); and Integer.valueOf();
		
		String s="200";
		//int i=Integer.parseInt(s);
		int i=Integer.valueOf(s);
		System.out.println(i);
		
		//if string having an group of characters, while converting it will throw an number format exceptional error
		String s1="xyz";
		int b=Integer.parseInt(s1);
		System.out.println(b);
		
		/*String to long =>Long.parseLong()
		  Long to string=>String.valueOf() or Long.toString()
		  string to float=>Float.parseFloat()
		  float to string=>String.valueOf() or Float.toString()
		  String to double=>Double.parseDouble()*/
	}

}
