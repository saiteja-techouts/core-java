package typecastingPackage;

class Emp{}
public class ObjectToString {
public static void main(String[] args) {
	//we can convert any object into string,string buffer, string builder.
	Emp e1=new Emp();
	String s1=e1.toString();
	String s2=String.valueOf(e1);
	System.out.println(s1);
	System.out.println(s2);
}
}
