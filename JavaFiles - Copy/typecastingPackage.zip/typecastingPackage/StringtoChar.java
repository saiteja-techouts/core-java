package typecastingPackage;

public class StringtoChar {
public static void main(String[] args) {
	String s="heLLo";
	//if we want to string into character, use CharAt(indexNumber of string)
	char c=s.charAt(3);
	System.out.println(c);
}
}
