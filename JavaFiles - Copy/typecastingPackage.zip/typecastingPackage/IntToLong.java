package typecastingPackage;

public class IntToLong {
public static void main(String[] args) {
	int i=12;
	long l=i;
	//there is no type casting required here for converting lower datatype to higher datatype
	System.out.println(l);
}
}
