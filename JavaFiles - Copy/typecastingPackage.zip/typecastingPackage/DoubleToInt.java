package typecastingPackage;

public class DoubleToInt {
public static void main(String[] args) {
	//it requires typecasting to convert higher datatype to lower datatype
	double d=111.0;
	int i1=(int)d;
	System.out.println(i1);
	
	//we can convert double object to int 
	
}
}
