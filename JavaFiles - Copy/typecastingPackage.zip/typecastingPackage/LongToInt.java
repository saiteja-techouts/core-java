package typecastingPackage;

public class LongToInt {
public static void main(String[] args) {
	//here we need to perform typecasting 
	long l1=34567;
	int i1=(int)l1;
	System.out.println(i1);
}
}
