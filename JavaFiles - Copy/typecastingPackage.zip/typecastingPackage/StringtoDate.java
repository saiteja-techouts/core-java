package typecastingPackage;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringtoDate {
public static void main(String[] args) throws ParseException {
	//if we want to convert string to date, use parse(),dateFormat class and SimpleDateFormat class
	String s1="26/11/1996";
	Date d1=new SimpleDateFormat("dd/MM/yyyy").parse(s1);
	System.out.println(s1+"\t"+d1);
}
}
