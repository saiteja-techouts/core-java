package typecastingPackage;

public class IntToDouble {
public static void main(String[] args) {
	//we can directly convert into double, because there is no typecasting for lower type to higher type
	int i=111;
	double d=i;
	System.out.println(d);
}
}
