package interfacePackage;
//if sub-class having two parent classes i.e., Multiple inheritance. it can be achieved by using interfaces.
public interface MultipleInheritane {
void Add();
void Sub();
}
interface Bmul //extends MultipleInheritance, it cannot be directly extends, it can be done from another class
{
	void Run();
}
class S implements MultipleInheritane,Bmul
{
 public void Add()
 {
	System.out.println("this is add method"); 
 }
 public void Sub()
 {
	 System.out.println("This is sub method");
 }
 public void Run()
 {
	 System.out.println("this is run method");
 }
 public static void main(String[] args) {
	S s1=new S();
	s1.Add();
}
}
