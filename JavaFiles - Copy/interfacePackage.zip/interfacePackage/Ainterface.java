package interfacePackage;

public interface Ainterface {
void Add();
}
class Binterface implements Ainterface
{
	public void Add()
	{
		System.out.println("this is binterface");
	}
	public static void main(String[] args) {
		Binterface b1=new Binterface();
		b1.Add();
	}
}

