package polymoPackage;

public class Acompile {

	static void run()
	{
		System.out.println("this is first run");
	}
	
}
