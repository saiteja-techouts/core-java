package polymoPackage;

public class Bcompile extends Acompile {
 static void run(int a,int b)
 {
	 System.out.println("this is inherited"+(a+b));
 }
 public static void main(String[] args) {
	Bcompile b1=new Bcompile();
	b1.run();
	b1.run(10,2);
}
}
