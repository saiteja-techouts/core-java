package polymoPackage;

import java.util.concurrent.atomic.DoubleAdder;

public class CompileTime {
static void add()
{
System.out.println("without parameters");	
}
static int add(int a,int b)
{
	return a + b;
}
public static void main(String[] args) {
	CompileTime ct=new CompileTime();
	ct.add();
	System.out.println(CompileTime.add(1, 2));
	ct.running();
	ct.running("sam");
}

public void running() {
	
}

public void running(String name) {
	
}
}
